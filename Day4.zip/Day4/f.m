function y=f(x)
y=x^3+2*x^2+10*x-20;
end