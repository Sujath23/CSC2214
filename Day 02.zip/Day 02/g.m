function y=g(x)
y=sqrt(x+1);
end